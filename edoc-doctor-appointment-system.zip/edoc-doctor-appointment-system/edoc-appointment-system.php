<?php
/*
Plugin Name: eDoc Appointment System
Description: A doctor appointment system integrated into WordPress.
Version: 1.0
Author: Neeraja
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Step 4.6: Database creation on activation
function edoc_create_database() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'edoc_appointments';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table_name (
        id INT NOT NULL AUTO_INCREMENT,
        patient_name VARCHAR(255) NOT NULL,
        patient_email VARCHAR(255) NOT NULL,
        doctor_name VARCHAR(255) NOT NULL,
        appointment_date DATE NOT NULL,
        appointment_time TIME NOT NULL,
        status VARCHAR(50) DEFAULT 'Pending',
        PRIMARY KEY (id)
    ) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'edoc_create_database');

// Step 4.7: Admin panel integration
function edoc_admin_menu() {
    add_menu_page(
        'eDoc Appointments',
        'Appointments',
        'manage_options',
        'edoc-appointments',
        'edoc_admin_page',
        'dashicons-calendar-alt',
        6
    );
}

function edoc_admin_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'edoc_appointments';
    $appointments = $wpdb->get_results("SELECT * FROM $table_name");

    echo '<div class="wrap">';
    echo '<h1>Manage Appointments</h1>';
    echo '<table class="widefat fixed striped">';
    echo '<thead>';
    echo '<tr><th>ID</th><th>Patient Name</th><th>Email</th><th>Doctor</th><th>Appointment Date</th><th>Time</th><th>Status</th></tr>';
    echo '</thead>';
    echo '<tbody>';
    if ($appointments) {
        foreach ($appointments as $appointment) {
            echo '<tr>';
            echo '<td>' . esc_html($appointment->id) . '</td>';
            echo '<td>' . esc_html($appointment->patient_name) . '</td>';
            echo '<td>' . esc_html($appointment->patient_email) . '</td>';
            echo '<td>' . esc_html($appointment->doctor_name) . '</td>';
            echo '<td>' . esc_html($appointment->appointment_date) . '</td>';
            echo '<td>' . esc_html($appointment->appointment_time) . '</td>';
            echo '<td>' . esc_html($appointment->status) . '</td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="7">No appointments found.</td></tr>';
    }
    echo '</tbody>';
    echo '</table>';
    echo '</div>';
}
add_action('admin_menu', 'edoc_admin_menu');
